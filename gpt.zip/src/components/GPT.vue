<template>
  <div class="flex justify-center items-center mb-4">
    <nav>
      <ul class="relative group">
        <li>
          <a href="#" class="cursor-pointer px-4 py-2 rounded-xl border-2 bg-[#111111] border-[#1b1b1bec]">Модели</a>
          <ul class="absolute left-0 hidden group-hover:block rounded-md pt-4 w-[180px]">
            <li><a href="#" @click="selectModel('GPT3.5 Turbo')" class="block px-2 py-2 rounded-xl border-2 bg-[#111111] border-[#1b1b1bec] mb-1">GPT3.5 Turbo</a></li>
            <li><a href="#" @click="selectModel('Blackbox')" class="block px-2 py-2 rounded-xl border-2 bg-[#111111] border-[#1b1b1bec] mb-1">Blackbox</a></li>
            <li><a href="#" @click="selectModel('Gemini Pro')" class="block px-2 py-2 rounded-xl border-2 bg-[#111111] border-[#1b1b1bec] mb-1">Gemini Pro</a></li>
            <li><a href="#" @click="selectModel('Gemini')" class="block px-2 py-2 rounded-xl border-2 bg-[#111111] border-[#1b1b1bec] mb-1">Gemini</a></li>
          </ul>
        </li>
      </ul>
    </nav>
  </div>

  <!-- Объединенный вывод сообщений -->
  <div v-for="(message, index) in messages" :key="index">
    <div v-if="message.role === 'user'" class="flex flex-row-reverse items-center mb-1">
      <h2 class="ml-2">User</h2>
      <div class="border p-1 rounded-xl flex items-center justify-center">
        <Icon icon="ri:user-3-line" width="1.5em" height="1.5em" />
      </div>
    </div>
    <div v-if="message.role === 'ai'" class="flex items-center mb-1">
      <div class="border p-1 rounded-xl flex items-center justify-center">
        <Icon icon="mingcute:ai-line" width="1.5em" height="1.5em" />
      </div>
      <h2 class="ml-2">Artificial Intelligence</h2>
    </div>
    <p :class="{ 'w-2/4 ml-auto text-right break-words': message.role === 'user', 'w-2/4': message.role === 'ai' }">
      {{ message.content }}
    </p>
  </div>

  <div class="fixed bottom-0 left-0 right-0 flex gap-2 justify-center p-4">
    <textarea
      required
      v-model="ai"
      type="text"
      placeholder="Мой крутой вопрос"
      class="border-2 bg-[#111111] border-[#1b1b1bec] focus:outline-none rounded resize-none w-full md:w-2/3 lg:w-3/4 xl:w-2/5 px-2 py-1"
      rows="1"
    />
    <button :disabled="sendTimeout" @click="send()" class="bg-blue-500 text-white focus:outline-none px-[9.5px] py-1 rounded">
      <Icon icon="mingcute:send-line" width="1.3em" height="1.3em" />
    </button>
  </div>
  <h1 class="flex justify-center items-center mt-8 mb-24 opacity-5">Dev OreoSync</h1>
</template>

<script setup>
import { Icon } from '@iconify/vue';
import axios from 'axios';
import { ref } from 'vue';

const ai = ref('');
const messages = ref([]);
const selectedModel = ref('GPT3.5 Turbo'); // По умолчанию выбранная модель
const link = ref("http://api.onlysq.ru/ai/v1");
const sendTimeout = ref(false);

const selectModel = (model) => {
  selectedModel.value = model;
  switch (model) {
    case 'GPT3.5 Turbo':
      link.value = "http://api.onlysq.ru/ai/v1";
      break;
    case 'Blackbox':
      link.value = "http://api.onlysq.ru/ai/v2";
      break;
    case 'Gemini Pro':
      link.value = "http://api.onlysq.ru/ai/v2";
      break;
    case 'Gemini':
      link.value = "http://api.onlysq.ru/ai/v2";
      break;
    default:
      link.value = "http://api.onlysq.ru/ai/v1";
  }
};

const send = async () => {
  if (sendTimeout.value || ai.value.trim() === '') return;

  messages.value.push({
    role: 'user',
    content: ai.value
  });

  sendTimeout.value = true;

  let dataToSend;
  switch (selectedModel.value) {
    case 'GPT3.5 Turbo':
      dataToSend = [
    {
        "role": "user",
        "content": ai.value
    }
]
      break;
    case 'Blackbox':
      dataToSend = {
    "model": "blackbox",
    "request": {
        "messages": [
            {
                "role": "user",
                "content": ai.value
            }
        ]
    }
}
      break;
    case 'Gemini Pro':
      dataToSend = {
    "model": "gemini-pro",
    "request": {
        "messages": [
            {
                "role": "user",
                "content": ai.value
            }
        ]
    }
}
      break;
    case 'Gemini':
      dataToSend = {
    "model": "gemini",
    "request": {
        "messages": [
            {
                "content": ai.value
            }
        ]
    }
}

      break;
    default:
      dataToSend = [
    {
        "role": "user",
        "content": ai.values
    }
]
  }

  try {
    const response = await axios.post(link.value, dataToSend);
    const aiResponse = response.data.answer;

    messages.value.push({
      role: 'ai',
      content: aiResponse
    });
  } catch (error) {
    console.error('Ошибка:', error);
  } finally {
    ai.value = ''; // Очистить поле ввода
    setTimeout(() => {
      sendTimeout.value = false;
    }, 5000);
  }
};
</script>
