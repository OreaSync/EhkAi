<script setup>
import GPT from './components/GPT.vue'
</script>

<template>
  <section>
    <GPT />
  </section>
</template>